package stepdefinition;

import static stepdefinition.DriverManager.getDriver;
import org.openqa.selenium.WebDriver;

import pageObjectModel.registration;
import pageObjectModel.signInstep;

public class BaseClass {
	
	public static WebDriver driver;

    public	static signInstep lk;
    public static registration nr;

	static
	{
		driver=getDriver();
	}
    

}
