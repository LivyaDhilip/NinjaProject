package stepdefinition;

public class ninjaArray extends BaseClass {

}
